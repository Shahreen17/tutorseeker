function initMap() {
    var map = new google.maps.Map(document.getElementById("map"), {
      center: { lat: 3.253981, lng: 101.729472},
      zoom: 18
    });
  }

  